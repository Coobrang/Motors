// Mobile Menu
console.clear();

const navExpand = document.querySelectorAll('.nav-expand');
const backLink = `<li class="nav-item"><a href="javascript:;" class="nav-link nav-back-link"><i class="fa-solid fa-caret-left"></i></a></li>`

navExpand.forEach(item => {
    item.querySelector('.nav-expand-content').insertAdjacentHTML('afterbegin', backLink);
    item.querySelector('.nav-link').addEventListener('click', () => item.classList.toggle('active'));
    item.querySelector('.nav-back-link').addEventListener('click', () => item.classList.remove('active'));
});

document.getElementById('ham').addEventListener('click', () => document.body.classList.toggle('nav-is-toggled'));


// Search Inventory
function setupDropdown(containerId, listId, selectTextId) {
    let container = document.getElementById(containerId);
    let list = container.querySelector("#" + listId);
    let selectText = container.querySelector("#" + selectTextId);

    container.onclick = function () {
        list.classList.toggle("open");
    };

    list.addEventListener("click", function (event) {
        if (event.target.classList.contains("options")) {
            selectText.innerHTML = event.target.innerHTML;
            list.classList.remove("open");
            event.stopPropagation(); // Stop event propagation
        }
    });
}

// Set up each dropdown individually
setupDropdown("select", "list", "selectText");
setupDropdown("select2", "list2", "selectText2");
setupDropdown("select3", "list3", "selectText3");


// Sticky Menu
document.addEventListener("DOMContentLoaded", function(){
    var header = document.querySelector(".main");
    var container = document.querySelector(".main .navigation");


    checkScroll();
    window.addEventListener("resize", checkScroll);

    window.addEventListener("scroll", function(){
        checkScroll();
    });

    function checkScroll() {
        var scrollPosition = window.pageXOffset || document.documentElement.scrollTop;

        var scrollThreshold = 100;

        var windowWidth = window.innerWidth || document.documentElement.clientWidth;
        var isWideScreen = windowWidth > 768;

        if (isWideScreen && scrollPosition > scrollThreshold) {
            header.classList.add("fixed");
        }else{
            header.classList.remove("fixed");
        }
    }
});